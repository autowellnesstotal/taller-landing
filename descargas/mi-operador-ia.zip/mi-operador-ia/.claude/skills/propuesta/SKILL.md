---
name: propuesta
description: Genera una propuesta comercial profesional lista para enviar a un cliente, guardada en output/. Triggers — /propuesta, "hazme una propuesta", "cotización para un cliente".
---

# Generador de propuestas — de prospecto a documento en 2 minutos

Generas una propuesta comercial profesional usando la oferta y voz del negocio.

## Antes de generar

1. Lee `perfil/negocio.md`. Si "Mi oferta" sigue en `[PENDIENTE]`, pide al usuario que
   corra `/entrevista` primero.
2. Pregunta SOLO estos 4 datos (uno por uno):
   - ¿Cómo se llama el cliente o su empresa?
   - ¿Qué problema quiere resolver? (en las palabras del cliente, si las tiene)
   - ¿Qué le vas a ofrecer? (de tu lista de servicios, o algo a la medida)
   - ¿Rango de inversión que le vas a proponer?

## Qué generar

`output/propuesta-<nombre-cliente>.md` con esta estructura:

1. **Encabezado** — para quién, de quién, fecha.
2. **Diagnóstico** (2 párrafos) — qué entiendes de su problema y qué le está costando
   no resolverlo. Usa las palabras del cliente.
3. **Solución propuesta** — tu enfoque en 3-5 pasos claros, sin tecnicismos.
4. **Entregables** — lista concreta de lo que recibe.
5. **Tiempos** — cuánto toma cada fase.
6. **Inversión** — el monto, qué incluye, y forma de pago sugerida (50% anticipo).
7. **Siguiente paso** — UNA acción concreta con mini-urgencia (ej. propuesta válida 15 días).

## Reglas

- Tono del perfil, pero siempre profesional — es un documento que ve un cliente.
- Español con tildes correctas. Cifras en formato $X,XXX MXN (o la moneda del perfil).
- Máximo 2 cuartillas de largo: las propuestas largas no se leen.
- Al terminar, muestra la ruta del archivo y sugiere: "Revísala y ajusta el precio si
  hace falta. ¿Te genero una versión corta para mandar por WhatsApp?"
