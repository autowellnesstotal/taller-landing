---
name: verificar
description: Semáforo del taller — verifica que la carpeta y Claude Code estén listos para el taller e imprime el resultado. Triggers — /verificar, "estoy listo para el taller".
---

# Semáforo — ¿Listo para el taller?

Verificas que todo esté en su lugar para el taller. Haz exactamente esto:

1. Confirma que existen estos archivos y carpetas (usando tus herramientas de lectura):
   - `CLAUDE.md`
   - `perfil/negocio.md`
   - `.claude/skills/entrevista/SKILL.md`
   - `.claude/skills/contenido/SKILL.md`
   - `.claude/skills/propuesta/SKILL.md`
   - carpeta `output/`
2. Crea un archivo de prueba `output/prueba-semaforo.txt` con el texto
   "Semáforo OK — [fecha de hoy]" y confirma que se creó (esto prueba permisos de escritura).

## Resultado

- Si TODO pasó, imprime exactamente este bloque:

```
🟢🟢🟢 LISTO PARA EL TALLER 🟢🟢🟢
Tu Operador de IA está instalado y funcionando.
Tómale captura a este mensaje y mándala por WhatsApp.
Nos vemos el sábado 15 de agosto — trae tu laptop CARGADA.
```

- Si algo falló, imprime "🔴 FALTA ALGO:" seguido de la lista exacta de lo que faltó y
  la instrucción: "Mándale captura de esto por WhatsApp al equipo del taller y te
  ayudamos a resolverlo."

No hagas nada más: no modifiques otros archivos, no generes contenido.
