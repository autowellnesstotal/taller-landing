---
name: contenido
description: Genera un calendario de contenido de 30 días + los posts redactados, con la voz del negocio, guardados en output/. Triggers — /contenido, "genera mi contenido del mes", "calendario de contenido".
---

# Máquina de contenido — 30 días en un comando

Generas un mes completo de contenido para redes sociales usando el contexto del negocio.

## Antes de generar

1. Lee `perfil/negocio.md` completo. Si la sección "Mi voz" o "Mi cliente ideal" siguen
   en `[PENDIENTE]`, detente y dile al usuario que primero corra `/entrevista`.
2. Pregunta SOLO estas 2 cosas (una por una):
   - ¿Para qué red generamos este mes? (si tiene varias en el perfil, que elija la principal)
   - ¿Hay algo que promocionar este mes? (oferta, evento, lanzamiento — o "nada especial")

## Qué generar

### 1. `output/calendario-30-dias.md`
Tabla con 30 filas: día, tipo de post, tema, gancho (primera línea), y llamada a la acción.
Mezcla equilibrada (regla 80/20 — valor/venta):
- ~10 posts de valor (tips, cómo-hacer, errores comunes del cliente ideal)
- ~6 de conexión (historia personal, detrás de cámaras, opinión)
- ~6 de prueba (casos, resultados, testimonios, antes/después)
- ~5 de venta directa (oferta, CTA claro)
- ~3 de conversación (preguntas, encuestas)

### 2. `output/posts-semana-1.md`
Los primeros 7 posts COMPLETOS, redactados listos para copiar y pegar:
con gancho, cuerpo, cierre y CTA, respetando el límite y formato de la red elegida
y la voz del perfil. Incluye sugerencia de imagen para cada uno (descripción, no archivo).

## Reglas

- La voz del perfil manda: si el perfil dice "sin tecnicismos", cero tecnicismos.
- Español con tildes correctas. Nada de contenido genérico que serviría para cualquier
  negocio — cada post debe mencionar especificidades del perfil.
- Al terminar, muestra la ruta de los 2 archivos y sugiere: "¿Quieres que redacte la
  semana 2, o ajustamos el tono de estos primero?"
