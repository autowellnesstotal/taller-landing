# Mi Operador de IA

Este archivo es la memoria de mi Operador. Claude lo lee al inicio de cada sesión.

## Quién soy

<!-- Se llena durante el taller con la skill de entrevista. No lo llenes a mano:
     abre Claude Code en esta carpeta y sigue las instrucciones del LEEME.txt -->

- **Nombre:** [PENDIENTE — se llena en el taller]
- **Negocio:** [PENDIENTE]
- **A qué me dedico:** [PENDIENTE]

## Mi contexto de trabajo

El perfil completo de mi negocio vive en `perfil/negocio.md`. **Léelo siempre antes de
generar contenido o propuestas** — ahí están mi cliente ideal, mi tono, mis servicios y
mis precios.

## Reglas para trabajar conmigo

1. Todo lo que generes se guarda en la carpeta `output/` — nunca solo en pantalla.
2. Escribe siempre en español, con ortografía y tildes correctas.
3. Usa mi tono de voz (está descrito en `perfil/negocio.md`). Si aún no está definido,
   pregúntame antes de asumir uno.
4. Sé concreto: entregables listos para usar, no borradores a medias.
5. Si falta información para hacer bien la tarea, hazme máximo 3 preguntas y continúa.
