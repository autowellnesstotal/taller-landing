# Perfil de mi negocio

<!-- PLANTILLA — se llena EN EL TALLER con la skill /entrevista.
     Claude te hará preguntas y escribirá este archivo por ti. -->

## El negocio
- **Nombre del negocio:** [PENDIENTE]
- **Qué vendo (productos/servicios):** [PENDIENTE]
- **Desde cuándo existe:** [PENDIENTE]
- **Dónde opero (ciudad / online):** [PENDIENTE]

## Mi cliente ideal
- **Quién es:** [PENDIENTE]
- **Qué problema le resuelvo:** [PENDIENTE]
- **Qué le duele / qué lo motiva:** [PENDIENTE]
- **Dónde pasa el tiempo (redes, lugares):** [PENDIENTE]

## Mi voz
- **Tono (formal, cercano, directo, con humor…):** [PENDIENTE]
- **Palabras o frases que SÍ uso:** [PENDIENTE]
- **Palabras que NUNCA usaría:** [PENDIENTE]

## Mi oferta
- **Servicios/productos y precios:** [PENDIENTE]
- **Mi diferenciador (por qué yo y no otro):** [PENDIENTE]
- **Mi llamada a la acción típica (WhatsApp, cita, tienda…):** [PENDIENTE]

## Redes y canales
- **Redes activas:** [PENDIENTE]
- **Frecuencia con la que publico hoy:** [PENDIENTE]
- **Canal por el que me contactan los clientes:** [PENDIENTE]
